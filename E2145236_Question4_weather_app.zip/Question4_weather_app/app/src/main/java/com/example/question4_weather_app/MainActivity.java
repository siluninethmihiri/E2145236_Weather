package com.example.question4_weather_app;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText eCity, eCountry;
    TextView tvR;
    private final String link = "https://api.openweathermap.org/data/2.5/weather";
    private final String idapp = "4767cd29c2f9b0df5a7cb246170dd210";
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eCity = findViewById(R.id.etC);
        eCountry = findViewById(R.id.etCou);
        tvR = findViewById(R.id.tvR);
    }

    public void getWeatherDetails(View view) {
        String tempUrl = "";
        String city = eCity.getText().toString().trim();
        String country = eCountry.getText().toString().trim();
        if (city.equals("")) {
            tvR.setText("Please fill mandatory!");
        } else {
            if (!country.equals("")) {
                tempUrl = link + "?q=" + city + "," + country + "&appid=" + idapp;
            } else {
                tempUrl = link + "?q=" + city + "&appid=" + idapp;
            }

            StringRequest stringRequest = new StringRequest(Request.Method.GET, tempUrl, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    String output = "";
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.getJSONArray("weather");
                        JSONObject jsonObjectWeather = jsonArray.getJSONObject(0);
                        String description = jsonObjectWeather.getString("description");
                        JSONObject jsonObjectMain = jsonResponse.getJSONObject("main");
                        double temp = jsonObjectMain.getDouble("temp") - 273.15;
                        int humidity = jsonObjectMain.getInt("humidity");
                        JSONObject jsonObjectSys = jsonResponse.getJSONObject("sys");
                        String countryName = jsonObjectSys.getString("country");
                        String cityName = jsonResponse.getString("name");
                        tvR.setTextColor(Color.rgb(68, 134, 199));
                        output += "Live weather " + cityName + " (" + countryName + ")"
                                + "\n Description: " + description
                                + "\n Temperature: " + df.format(temp) + " °C"
                                + "\n Humidity: " + humidity + "%";

                        tvR.setText(output);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(stringRequest);
        }
    }
}
