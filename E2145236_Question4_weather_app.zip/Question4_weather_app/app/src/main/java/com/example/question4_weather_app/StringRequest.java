package com.example.question4_weather_app;

public class StringRequest {
}
