package com.example.question4_weather_app;

public class RequestQueue {
    public void add(StringRequest stringRequest) {
    }
}
